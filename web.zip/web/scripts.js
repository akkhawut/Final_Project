 $(window).scroll(function(){
        var scroll = $(document).scrollTop();
        var s = {
            "nohuman" : scroll >= 0 && scroll < 1600,
            "human1" : scroll >= 1600 && scroll < 2000,
            "human2" : scroll >= 2000 && scroll < 2400,
            "human3" : scroll >= 2400 && scroll < 2800,
            "human4" : scroll >= 2800 && scroll < 3200,
        }
        console.log(scroll)
        console.log(s.human1)
        if( scroll > 1500 ){
            switch (true) {
                case s.nohuman :
                $('#human_1').addClass('d-none').removeClass('animated fadeInDown')
                $('#eye').addClass('d-none').removeClass('animated fadeInDown')

                break;
            case s.human1 :
            $('#eye').removeClass('d-none').addClass('animated fadeInDown')
                $('#human_1').removeClass('d-none').addClass('animated fadeInDown')
                $('#human_2').addClass('d-none').removeClass('animated fadeInDown')
                $('#human_3').addClass('d-none').removeClass('animated fadeInDown')
                $('#heart').addClass('d-none').removeClass('animated fadeInDown')
                break;
            case s.human2 :
            $('#eye').addClass('d-none').removeClass('animated fadeInDown')
            $('#heart').removeClass('d-none').addClass('animated fadeInDown')
                $('#human_1').addClass('d-none').removeClass('animated fadeInDown')
                $('#human_2').removeClass('d-none').addClass('animated fadeInDown')
                $('#human_3').addClass('d-none').removeClass('animated fadeInDown')
                $('#kidney').addClass('d-none').removeClass('animated fadeInDown')
                break;
             case s.human3 :
             $('#foot').addClass('d-none').removeClass('animated fadeInDown')
             $('#kidney').removeClass('d-none').addClass('animated fadeInDown')
             $('#heart').addClass('d-none').removeClass('animated fadeInDown')
             $('#human_2').addClass('d-none').removeClass('animated fadeInDown')
             $('#human_3').removeClass('d-none').addClass('animated fadeInDown')
             $('#human_4').addClass('d-none').removeClass('animated fadeInDown')
                break;
                case s.human4 :
                $('#foot').removeClass('d-none').addClass('animated fadeInDown')
                $('#kidney').addClass('d-none').removeClass('animated fadeInDown')
             $('#human_3').addClass('d-none').removeClass('animated fadeInDown')
             $('#human_4').removeClass('d-none').addClass('animated fadeInDown')
                break;
                
            default:
                console.log('Sorry, we are out of ' + '.');
            }
        }
    });

$(".mat-input").focus(function(){
$(this).parent().addClass("is-active is-completed");
});

$(".mat-input").focusout(function(){
  if($(this).val() === "")
    $(this).parent().removeClass("is-completed");
  $(this).parent().removeClass("is-active");
})



$(document).ready(function() {
    $("#con1").click(function(){
        $('#cond1').removeClass('d-none');
        $('#cond2').addClass('d-none');
        $('#cond3').addClass('d-none');
        $('#cond4').addClass('d-none');
        $('#cond5').addClass('d-none');
        $('#cond6').addClass('d-none');
    }); 
});

$(document).ready(function() {
    $("#con2").click(function(){
        $('#cond2').removeClass('d-none');
        $('#cond1').addClass('d-none');
        $('#cond3').addClass('d-none');
        $('#cond4').addClass('d-none');
        $('#cond5').addClass('d-none');
        $('#cond6').addClass('d-none');
    }); 
});
$(document).ready(function() {
    $("#con3").click(function(){
        $('#cond3').removeClass('d-none');
        $('#cond1').addClass('d-none');
        $('#cond2').addClass('d-none');
        $('#cond4').addClass('d-none');
        $('#cond5').addClass('d-none');
        $('#cond6').addClass('d-none');
    }); 
});
$(document).ready(function() {
    $("#con4").click(function(){
        $('#cond4').removeClass('d-none');
        $('#cond1').addClass('d-none');
        $('#cond2').addClass('d-none');
        $('#cond3').addClass('d-none');
        $('#cond5').addClass('d-none');
        $('#cond6').addClass('d-none');
    }); 
});
$(document).ready(function() {
    $("#con5").click(function(){
        $('#cond5').removeClass('d-none');
        $('#cond1').addClass('d-none');
        $('#cond2').addClass('d-none');
        $('#cond3').addClass('d-none');
        $('#cond4').addClass('d-none');
        $('#cond6').addClass('d-none');
    }); 
});
$(document).ready(function() {
    $("#con6").click(function(){
        $('#cond6').removeClass('d-none');
        $('#cond1').addClass('d-none');
        $('#cond2').addClass('d-none');
        $('#cond3').addClass('d-none');
        $('#cond4').addClass('d-none');
        $('#cond5').addClass('d-none');
    }); 
});

$(":radio").on("change", function(){
    var total = 0;
    $(":radio:checked").each(function(){
        total += Number(this.value);
    });
    
    $("#total").text(total);
});

